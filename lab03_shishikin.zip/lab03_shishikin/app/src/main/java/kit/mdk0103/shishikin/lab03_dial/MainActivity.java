package kit.mdk0103.shishikin.lab03_dial;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calculate(View view) {
        CheckBox checkBoxApl = findViewById(R.id.checkBoxApl);
        CheckBox checkBoxStrwbry = findViewById(R.id.checkBoxStrwbry);
        CheckBox checkBoxBlbry = findViewById(R.id.checkBoxBlbry);
        CheckBox checkBoxPts = findViewById(R.id.checkBoxPts);

        EditText inputApl = findViewById(R.id.inputEditTextApl);
        EditText inputStrwbry = findViewById(R.id.inputEditTextStrwbry);
        EditText inputBlbry = findViewById(R.id.inputEditTextBlbry);
        EditText inputPts = findViewById(R.id.inputEditTextPts);

        EditText priceApl = findViewById(R.id.inputEditTextPriceApl);
        EditText priceStrwbry = findViewById(R.id.inputEditTextPriceStrwbry);
        EditText priceBlbry = findViewById(R.id.inputEditTextPriceBlbry);
        EditText pricePts = findViewById(R.id.inputEditTextPricePts);

        RadioButton toast = findViewById(R.id.radioButtonTst);
        RadioButton dialog = findViewById(R.id.radioButtonDlg);

        int res = 0;

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("total");
        builder.setMessage("total " + res);
        builder.setCancelable(true);

        if (checkBoxApl.isChecked()) {
            res += Integer.parseInt(inputApl.getText().toString()) * Integer.parseInt(priceApl.getText().toString());
        }
        if (checkBoxStrwbry.isChecked()) {
            res += Integer.parseInt(inputStrwbry.getText().toString()) * Integer.parseInt(priceStrwbry.getText().toString());;
        }
        if (checkBoxBlbry.isChecked()) {
            res += Integer.parseInt(inputBlbry.getText().toString()) * Integer.parseInt(priceBlbry.getText().toString());
        }
        if (checkBoxPts.isChecked()) {
            res += Integer.parseInt(inputPts.getText().toString()) * Integer.parseInt(pricePts.getText().toString());
        }

        if (toast.isChecked()) {
            Toast.makeText(this, "total " + res, Toast.LENGTH_LONG).show();
        }
        if (dialog.isChecked()){
            builder.show();
        }
    }
}